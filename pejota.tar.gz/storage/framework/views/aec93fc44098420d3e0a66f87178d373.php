<?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('comments', ['record' => $record ?? $entry?->getRecord() ?? $component?->getRecord() ?? (method_exists($this, 'getRecord') ? $this->getRecord() : (property_exists($this, 'record') ? $this->record : null))]);

$__key = null;

$__key ??= \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::generateKey('lw-271092036-0', $__key);

$__html = app('livewire')->mount($__name, $__params, $__key);

echo $__html;

unset($__html);
unset($__key);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
<?php /**PATH /var/www/html/resources/views/vendor/filament-comments/component.blade.php ENDPATH**/ ?>