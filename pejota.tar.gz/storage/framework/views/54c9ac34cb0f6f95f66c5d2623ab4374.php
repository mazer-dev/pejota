<div>
    <?php echo e($this->createTask('')); ?>

    <?php echo e($this->createSession('')); ?>

    <?php echo e($this->createNote('')); ?>

</div>
<?php /**PATH /var/www/html/resources/views/livewire/top-navigate-action.blade.php ENDPATH**/ ?>