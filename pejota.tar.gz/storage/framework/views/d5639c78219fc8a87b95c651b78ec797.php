<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title><?php echo e($invoice->title); ?></title>
    <style>
        * {
            -webkit-box-sizing: border-box;
            -moz-box-sizing: border-box;
            box-sizing: border-box;
        }

        h1, h2, h3, h4, h5, h6, p, span, div {
            font-family: DejaVu Sans;
            font-size: 10px;
            font-weight: normal;
        }

        th, td {
            font-family: DejaVu Sans;
            font-size: 10px;
        }

        .panel {
            margin-bottom: 20px;
            background-color: #fff;
            border: 1px solid transparent;
            border-radius: 4px;
            -webkit-box-shadow: 0 1px 1px rgba(0, 0, 0, .05);
            box-shadow: 0 1px 1px rgba(0, 0, 0, .05);
        }

        .panel-default {
            border-color: #ddd;
        }

        .panel-body {
            padding: 15px;
        }

        table {
            width: 100%;
            max-width: 100%;
            margin-bottom: 0px;
            border-spacing: 0;
            border-collapse: collapse;
            background-color: transparent;

        }

        thead {
            text-align: left;
            display: table-header-group;
            vertical-align: middle;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 6px;
        }

        .well {
            min-height: 20px;
            padding: 19px;
            margin-bottom: 20px;
            background-color: #f5f5f5;
            border: 1px solid #e3e3e3;
            border-radius: 4px;
            -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, .05);
            box-shadow: inset 0 1px 1px rgba(0, 0, 0, .05);
        }
    </style>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($invoice->duplicate_header): ?>
        <style>
            @page {
                margin-top: 140px;
            }

            header {
                top: -100px;
                position: fixed;
            }
        </style>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
</head>
<body>
<?php
    $media = $invoice->company->getFirstMedia();
    $path_img = null;
    if ($media) {
        $data = file_get_contents($media->getPath(), false);
        $img_base_64 = base64_encode($data);
        $path_img = 'data:image/' . $media->getTypeFromMime() . ';base64,' . $img_base_64;
    }
?>
<?php
    $invoiceCurrency = $invoice->currency ?? \App\Helpers\PejotaHelper::getUserCurrency();
    $invoiceLocale = \App\Helpers\PejotaHelper::getUserLocate();
    $money = fn ($value) => \Illuminate\Support\Number::currency((float) $value, $invoiceCurrency, $invoiceLocale);
?>

<header>
    <div style="position:absolute; right:0;">
        <img class="img-rounded" style="height: 50pt;" src="<?php echo e($path_img); ?>">
    </div>
    <div style="margin-left:0pt;">
        <span style="font-size: 1.5rem; font-weight: bold; "><?php echo app('translator')->get('Invoice'); ?></span><br/>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($invoice->number): ?>
            <span style="font-size: 1rem;">
                <b>#</b><?php echo e($invoice->number); ?>

            </span>
            <br/>
            <br/>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        <b><?php echo app('translator')->get('Date'); ?>: </b> <?php echo e($invoice->created_at->format(\App\Helpers\PejotaHelper::getUserDateFormat())); ?>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($invoice->due_date): ?>
            <span style="position:absolute; right: 0;">
                <b><?php echo app('translator')->get('Due date'); ?>: </b><?php echo e($invoice->due_date->format(\App\Helpers\PejotaHelper::getUserDateFormat())); ?><br/>
            </span>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </div>
</header>
<main>
    <div style="clear:both; position:relative;">
        <div style="position:absolute; left:0pt; width:250pt;">
            <h4>Business Details:</h4>
            <div class="panel panel-default">
                <div class="panel-body">
                    <?php echo e($invoice->company->name); ?><br/>
                    <?php echo e($invoice->company->phone ?? ''); ?><br/>
                    <?php echo e($invoice->company->email ?? ''); ?><br/>
                    <?php echo e($invoice->company->website ?? ''); ?><br/>
                </div>
            </div>
        </div>
        <div style="margin-left: 300pt;">
            <h4>Customer Details:</h4>
            <div class="panel panel-default">
                <div class="panel-body">
                    <?php echo e($invoice->client->name); ?> | #<?php echo e($invoice->client->id); ?><br/>
                    <?php echo e($invoice->client->phone ?? ''); ?><br/>
                    <?php echo e($invoice->client->email ?? ''); ?><br/>
                </div>
            </div>
        </div>
    </div>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($invoice->extra_info): ?>
        <h4><?php echo app('translator')->get('Extra Information:'); ?></h4>
        <div class="panel panel-default">
            <div class="panel-body">
                <?php echo nl2br($invoice->extra_info); ?>

            </div>
        </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <h4>Items:</h4>
    <table class="table table-bordered">
        <thead>
        <tr>
            <th>#</th>
            <th><?php echo app('translator')->get('Name'); ?></th>
            <th style="text-align: right"><?php echo app('translator')->get('Quantity'); ?></th>
            <th><?php echo app('translator')->get('Unit'); ?></th>
            <th style="text-align: right"><?php echo app('translator')->get('Price'); ?></th>
            <th style="text-align: right"><?php echo app('translator')->get('Discount'); ?></th>
            <th style="text-align: right"><?php echo app('translator')->get('Total'); ?></th>
        </tr>
        </thead>
        <tbody>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $invoice->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($loop->iteration); ?></td>
                <td><?php echo e($item->name); ?></td>
                <td style="text-align: right"><?php echo e(\Illuminate\Support\Number::format((float) $item->quantity, maxPrecision: 2, locale: \App\Helpers\PejotaHelper::getUserLocate())); ?></td>
                <td><?php echo e($item->unit->name); ?></td>
                <td style="text-align: right"><?php echo e($money($item->price)); ?></td>
                <td style="text-align: right"><?php echo e($money($invoice->discount)); ?></td>
                <td style="text-align: right"><?php echo e($money($item->total)); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </tbody>
    </table>
    <div style="clear:both; position:relative;">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($invoice->notes): ?>
            <div style="position:absolute; left:0pt; width:250pt;">
                <h4>Notes:</h4>
                <div class="panel panel-default">
                    <div class="panel-body">
                        <?php echo e($invoice->notes); ?>

                    </div>
                </div>
            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <div style="margin-left: 300pt;">
            <h4>Total:</h4>
            <table class="table table-bordered">
                <tbody>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($invoice->dicount): ?>
                    <tr>
                        <td><b>Discount</b></td>
                        <td><?php echo e($invoice->dicount); ?></td>
                    </tr>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <tr>
                    <td><b>TOTAL</b></td>
                    <td style="text-align: right"><b><?php echo e($money($invoice->total)); ?></b></td>
                </tr>
                </tbody>
            </table>
        </div>
    </div>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($invoice->footnote): ?>
        <br/><br/>
        <div class="well">
            <?php echo e($invoice->footnote); ?>

        </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
</main>

<!-- Page count -->
<script type="text/php">
    if (isset($pdf) && $GLOBALS['with_pagination'] && $PAGE_COUNT > 1) {
        $pageText = "{PAGE_NUM} of {PAGE_COUNT}";
        $pdf->page_text(($pdf->get_width()/2) - (strlen($pageText) / 2), $pdf->get_height()-20, $pageText, $fontMetrics->get_font("DejaVu Sans, Arial, Helvetica, sans-serif", "normal"), 7, array(0,0,0));
    }
</script>
</body>
</html>
<?php /**PATH /var/www/html/resources/views/invoice/pdf.blade.php ENDPATH**/ ?>