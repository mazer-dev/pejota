<div
    x-data="{ open: false }"
    class="relative"
    wire:poll.30s
>
    <button
        type="button"
        @click="open = ! open"
        x-tooltip="{ content: '<?php echo app('translator')->get('Work sessions'); ?> - <?php echo app('translator')->get('Running'); ?>', theme: $store.theme }"
    >
        <span style="--c-50:var(--primary-50);--c-400:var(--primary-400);--c-600:var(--primary-600);"
              class="fi-badge flex items-center justify-center gap-x-1 rounded-md text-xs font-medium ring-1 ring-inset px-2 min-w-[theme(spacing.6)] py-1 fi-color-custom bg-custom-50 text-custom-600 ring-custom-600/10 dark:bg-custom-400/10 dark:text-custom-400 dark:ring-custom-400/30 fi-color-primary">
            <?php if (isset($component)) { $__componentOriginalbfc641e0710ce04e5fe02876ffc6f950 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbfc641e0710ce04e5fe02876ffc6f950 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.icon','data' => ['icon' => ''.e(\App\Filament\App\Resources\WorkSessionResource::getNavigationIcon()).'','class' => 'h-5 w-5 text-gray-500 dark:text-gray-400']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icon' => ''.e(\App\Filament\App\Resources\WorkSessionResource::getNavigationIcon()).'','class' => 'h-5 w-5 text-gray-500 dark:text-gray-400']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbfc641e0710ce04e5fe02876ffc6f950)): ?>
<?php $attributes = $__attributesOriginalbfc641e0710ce04e5fe02876ffc6f950; ?>
<?php unset($__attributesOriginalbfc641e0710ce04e5fe02876ffc6f950); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbfc641e0710ce04e5fe02876ffc6f950)): ?>
<?php $component = $__componentOriginalbfc641e0710ce04e5fe02876ffc6f950; ?>
<?php unset($__componentOriginalbfc641e0710ce04e5fe02876ffc6f950); ?>
<?php endif; ?>
            <span class="grid"><span class="truncate"><?php echo e($count); ?></span></span>
        </span>
    </button>

    <div
        x-show="open"
        x-cloak
        @click.outside="open = false"
        x-transition
        class="absolute end-0 z-50 mt-2 rounded-lg bg-white p-3 shadow-lg ring-1 ring-gray-950/5 dark:bg-gray-900 dark:ring-white/10"
        style="width: min(calc(100vw - 2rem), 28rem);"
    >
        <h3 class="mb-2 text-sm font-semibold text-gray-700 dark:text-gray-200">
            <?php echo app('translator')->get('Running'); ?>
        </h3>

        <ul class="mb-3 flex flex-col gap-2">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $running; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $session): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <li wire:key="ws-<?php echo e($session->id); ?>"
                    class="flex items-center justify-between gap-2 rounded-md bg-gray-50 px-2 py-1 dark:bg-white/5">
                    <div class="min-w-0">
                        <a
                            href="<?php echo e(\App\Filament\App\Resources\WorkSessionResource::getUrl('edit', ['record' => $session])); ?>"
                            class="block truncate text-sm font-medium text-primary-600 hover:underline dark:text-primary-400"
                        >
                            <?php echo e($session->title); ?>

                        </a>
                        <p class="truncate text-xs text-gray-500">
                            <?php echo e($session->client?->labelName); ?>

                            <span
                                x-data="{
                                    start: <?php echo e($session->start->timestamp); ?>,
                                    text: '00:00',
                                    tick() {
                                        const s = Math.max(0, Math.floor(Date.now() / 1000) - this.start);
                                        const h = String(Math.floor(s / 3600)).padStart(2, '0');
                                        const m = String(Math.floor((s % 3600) / 60)).padStart(2, '0');
                                        this.text = h + ':' + m;
                                    },
                                }"
                                x-init="tick(); setInterval(() => tick(), 30000)"
                                x-text="text"
                                class="font-mono"
                            ></span>
                        </p>
                    </div>
                    <button
                        type="button"
                        wire:click="stopSession(<?php echo e($session->id); ?>)"
                        x-tooltip="{ content: '<?php echo app('translator')->get('Stop session'); ?>', theme: $store.theme }"
                        class="shrink-0 rounded-md p-1 text-danger-600 hover:bg-danger-50 hover:text-danger-500 dark:text-danger-400 dark:hover:bg-danger-500/10"
                    >
                        <?php if (isset($component)) { $__componentOriginalbfc641e0710ce04e5fe02876ffc6f950 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbfc641e0710ce04e5fe02876ffc6f950 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.icon','data' => ['icon' => 'heroicon-m-stop-circle','class' => 'h-5 w-5']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icon' => 'heroicon-m-stop-circle','class' => 'h-5 w-5']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbfc641e0710ce04e5fe02876ffc6f950)): ?>
<?php $attributes = $__attributesOriginalbfc641e0710ce04e5fe02876ffc6f950; ?>
<?php unset($__attributesOriginalbfc641e0710ce04e5fe02876ffc6f950); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbfc641e0710ce04e5fe02876ffc6f950)): ?>
<?php $component = $__componentOriginalbfc641e0710ce04e5fe02876ffc6f950; ?>
<?php unset($__componentOriginalbfc641e0710ce04e5fe02876ffc6f950); ?>
<?php endif; ?>
                    </button>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <li class="text-xs text-gray-500"><?php echo app('translator')->get('No running sessions'); ?></li>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </ul>

        <div class="flex flex-col gap-2 border-t border-gray-100 pt-2 dark:border-white/10">
            <input
                type="text"
                wire:model="newTitle"
                placeholder="<?php echo e(__('Title')); ?>"
                class="fi-input block w-full rounded-md border-gray-300 text-sm dark:bg-white/5 dark:text-white"
            />

            <?php echo $__env->make('livewire.partials.searchable-select', [
                'field' => 'newClient',
                'searchProp' => 'clientSearch',
                'options' => $clientOptions,
                'selectedLabel' => $selectedClientLabel,
                'placeholder' => __('Client'),
            ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            <?php echo $__env->make('livewire.partials.searchable-select', [
                'field' => 'newProject',
                'searchProp' => 'projectSearch',
                'options' => $projectOptions,
                'selectedLabel' => $selectedProjectLabel,
                'placeholder' => __('Project'),
            ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            <?php echo $__env->make('livewire.partials.searchable-select', [
                'field' => 'newTask',
                'searchProp' => 'taskSearch',
                'options' => $taskOptions,
                'selectedLabel' => $selectedTaskLabel,
                'placeholder' => __('Task'),
            ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            <button
                type="button"
                wire:click="startSession"
                class="rounded-md bg-primary-600 px-2 py-1.5 text-sm font-medium text-white hover:bg-primary-500"
            >
                + <?php echo app('translator')->get('Start'); ?>
            </button>
        </div>
    </div>
</div>
<?php /**PATH /var/www/html/resources/views/livewire/work-sessions-top-nav.blade.php ENDPATH**/ ?>