<div>
    <?php echo e($this->table); ?>

</div>
<?php /**PATH /var/www/html/resources/views/livewire/projects/list-tasks.blade.php ENDPATH**/ ?>