<div style="margin-bottom: 16px;">
    <h2 style="margin: 0;"><?php echo e(auth()->user()->company->name ?? config('app.name')); ?></h2>
    <p style="margin: 2px 0;">
        <?php echo e(__('Timesheet')); ?> — <?php echo e($data->client->name); ?>

    </p>
    <p style="margin: 2px 0; color: #555;">
        <?php echo e($data->from->format('Y-m-d')); ?> → <?php echo e($data->to->format('Y-m-d')); ?>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($data->includeValue): ?>
            · <?php echo e($data->currency); ?>

        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </p>
</div>
<?php /**PATH /var/www/html/resources/views/timesheet/partials/client-header.blade.php ENDPATH**/ ?>