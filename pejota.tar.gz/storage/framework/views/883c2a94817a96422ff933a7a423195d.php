
<div x-data="{ open: false }" class="relative" @click.outside="open = false">
    <button
        type="button"
        @click="open = ! open"
        class="fi-input flex w-full items-center justify-between gap-2 rounded-md border-gray-300 px-3 py-2 text-left text-sm dark:bg-white/5 dark:text-white"
    >
        <span class="truncate <?php echo e($selectedLabel ? '' : 'text-gray-400'); ?>"><?php echo e($selectedLabel ?: $placeholder); ?></span>
        <?php if (isset($component)) { $__componentOriginalbfc641e0710ce04e5fe02876ffc6f950 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbfc641e0710ce04e5fe02876ffc6f950 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.icon','data' => ['icon' => 'heroicon-m-chevron-up-down','class' => 'h-4 w-4 shrink-0 text-gray-400']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icon' => 'heroicon-m-chevron-up-down','class' => 'h-4 w-4 shrink-0 text-gray-400']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbfc641e0710ce04e5fe02876ffc6f950)): ?>
<?php $attributes = $__attributesOriginalbfc641e0710ce04e5fe02876ffc6f950; ?>
<?php unset($__attributesOriginalbfc641e0710ce04e5fe02876ffc6f950); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbfc641e0710ce04e5fe02876ffc6f950)): ?>
<?php $component = $__componentOriginalbfc641e0710ce04e5fe02876ffc6f950; ?>
<?php unset($__componentOriginalbfc641e0710ce04e5fe02876ffc6f950); ?>
<?php endif; ?>
    </button>

    <div
        x-show="open"
        x-cloak
        x-transition
        class="absolute z-50 mt-1 w-full rounded-md bg-white shadow-lg ring-1 ring-gray-950/5 dark:bg-gray-900 dark:ring-white/10"
    >
        <input
            type="text"
            wire:model.live.debounce.300ms="<?php echo e($searchProp); ?>"
            placeholder="<?php echo e(__('Search...')); ?>"
            class="fi-input block w-full rounded-t-md border-0 border-b border-gray-200 text-sm focus:ring-0 dark:border-white/10 dark:bg-white/5 dark:text-white"
            @click.stop
        />
        <ul class="max-h-48 overflow-y-auto py-1">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($selectedLabel): ?>
                <li>
                    <button
                        type="button"
                        wire:click="$set('<?php echo e($field); ?>', null)"
                        @click="open = false"
                        class="block w-full px-3 py-1.5 text-left text-xs text-gray-400 hover:bg-gray-50 dark:hover:bg-white/5"
                    >
                        <?php echo e(__('Clear selection')); ?>

                    </button>
                </li>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <li wire:key="<?php echo e($field); ?>-opt-<?php echo e($id); ?>">
                    <button
                        type="button"
                        wire:click="$set('<?php echo e($field); ?>', <?php echo e($id); ?>)"
                        @click="open = false"
                        class="block w-full truncate px-3 py-1.5 text-left text-sm text-gray-700 hover:bg-gray-50 dark:text-gray-200 dark:hover:bg-white/5"
                    >
                        <?php echo e($label); ?>

                    </button>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <li class="px-3 py-1.5 text-xs text-gray-400"><?php echo e(__('No results')); ?></li>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </ul>
    </div>
</div>
<?php /**PATH /var/www/html/resources/views/livewire/partials/searchable-select.blade.php ENDPATH**/ ?>