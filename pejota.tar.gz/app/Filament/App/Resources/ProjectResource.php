<?php

namespace App\Filament\App\Resources;

use App\Enums\MenuGroupsEnum;
use App\Enums\MenuSortEnum;
use App\Filament\App\Resources\ProjectResource\Pages\CreateProject;
use App\Filament\App\Resources\ProjectResource\Pages\EditProject;
use App\Filament\App\Resources\ProjectResource\Pages\ListProjects;
use App\Filament\App\Resources\ProjectResource\Pages\ViewProject;
use App\Helpers\PejotaHelper;
use App\Livewire\Projects\ListTasks;
use App\Models\Project;
use Filament\Forms\Components\RichEditor;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\SpatieTagsInput;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
use Filament\Forms\Form;
use Filament\Infolists\Components\Actions;
use Filament\Infolists\Components\Actions\Action;
use Filament\Infolists\Components\Livewire;
use Filament\Infolists\Components\Section;
use Filament\Infolists\Components\SpatieTagsEntry;
use Filament\Infolists\Components\Split;
use Filament\Infolists\Components\TextEntry;
use Filament\Infolists\Components\TextEntry\TextEntrySize;
use Filament\Infolists\Infolist;
use Filament\Resources\Resource;
use Filament\Support\Colors\Color;
use Filament\Support\Enums\FontWeight;
use Filament\Tables\Actions\BulkActionGroup;
use Filament\Tables\Actions\DeleteBulkAction;
use Filament\Tables\Actions\EditAction;
use Filament\Tables\Actions\ViewAction;
use Filament\Tables\Columns\SpatieTagsColumn;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Columns\ToggleColumn;
use Filament\Tables\Filters\SelectFilter;
use Filament\Tables\Filters\TernaryFilter;
use Filament\Tables\Grouping\Group;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\HtmlString;

class ProjectResource extends Resource
{
    protected static ?string $model = Project::class;

    protected static ?string $navigationIcon = 'heroicon-o-presentation-chart-bar';

    protected static ?int $navigationSort = MenuSortEnum::PROJECTS->value;

    public static function getNavigationGroup(): ?string
    {
        return __(MenuGroupsEnum::ADMINISTRATION->value);
    }

    public static function getModelLabel(): string
    {
        return __('Project');
    }

    public static function form(Form $form): Form
    {
        return $form
            ->columns(1)
            ->schema(
                self::getFormComponents()
            );
    }

    public static function table(Table $table): Table
    {
        return $table
            ->striped()
            ->columns([
                TextColumn::make('name')
                    ->translateLabel()
                    ->searchable()
                    ->sortable(),

                TextColumn::make('client.name')
                    ->translateLabel()
                    ->searchable()
                    ->sortable(),
                ToggleColumn::make('active')
                    ->translateLabel(),

                SpatieTagsColumn::make('tags'),

                TextColumn::make('created_at')
                    ->translateLabel()
                    ->dateTime()
                    ->timezone(PejotaHelper::getUserTimeZone())
                    ->sortable()
                    ->toggleable(isToggledHiddenByDefault: true),
                TextColumn::make('updated_at')
                    ->translateLabel()
                    ->dateTime()
                    ->timezone(PejotaHelper::getUserTimeZone())
                    ->sortable()
                    ->toggleable(isToggledHiddenByDefault: true),
            ])
            ->filters([
                SelectFilter::make('client')
                    ->relationship('client', 'name'),
                TernaryFilter::make('active'),
            ])
            ->groups([
                Group::make('client.name'),
            ])
            ->actions([
                ViewAction::make(),
                EditAction::make(),
            ])
            ->bulkActions([
                BulkActionGroup::make([
                    DeleteBulkAction::make(),
                ]),
            ])
            ->defaultSort('name', 'asc')
            ->persistFiltersInSession();
    }

    public static function infolist(Infolist $infolist): Infolist
    {
        return $infolist
            ->schema([
                Split::make([
                    Section::make([
                        TextEntry::make('name')
                            ->translateLabel()
                            ->size(TextEntrySize::Large)
                            ->weight(FontWeight::Bold)
                            ->label(''),

                        SpatieTagsEntry::make('tags')
                            ->label(''),

                        TextEntry::make('client.name')
                            ->translateLabel()
                            ->label('')
                            ->icon('heroicon-o-building-office'),

                        TextEntry::make('description')
                            ->translateLabel()
                            ->formatStateUsing(fn (string $state): HtmlString => new HtmlString($state))
                            ->label('')
                            ->icon('heroicon-o-document-text'),

                    ]),

                    Section::make([
                        TextEntry::make('active')
                            ->translateLabel()
                            ->formatStateUsing(fn (string $state): string => $state ? __('Yes') : __('No')),

                        TextEntry::make('created_at')
                            ->translateLabel()
                            ->dateTime()
                            ->timezone(PejotaHelper::getUserTimeZone()),
                        TextEntry::make('updated_at')
                            ->translateLabel()
                            ->dateTime()
                            ->timezone(PejotaHelper::getUserTimeZone()),
                        Actions::make([
                            Action::make('edit')
                                ->translateLabel()
                                ->url(
                                    fn (Model $record) => "{$record->id}/edit"
                                )
                                ->icon('heroicon-o-pencil'),

                            Action::make('back')
                                ->translateLabel()
                                ->url(
                                    fn (Model $record) => './.'
                                )
                                ->icon('heroicon-o-chevron-left')
                                ->color(Color::Neutral),
                        ]),
                    ])->grow(false),

                ])
                    ->from('md')
                    ->columnSpanFull(),

                Section::make('Tasks')
                    ->translateLabel()
                    ->schema([
                        Livewire::make(
                            ListTasks::class,
                            fn (Model $record) => ['project' => $record]
                        ),
                    ]),
            ]);
    }

    public static function getRelations(): array
    {
        return [
            //
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => ListProjects::route('/'),
            'create' => CreateProject::route('/create'),
            'view' => ViewProject::route('/{record}'),
            'edit' => EditProject::route('/{record}/edit'),
        ];
    }

    public static function getFormComponents(): array
    {
        return [
            Select::make('client')
                ->translateLabel()
                ->relationship('client', 'name')
                ->preload(),
            TextInput::make('name')
                ->translateLabel()
                ->required(),
            TextInput::make('hourly_rate')
                ->translateLabel()
                ->numeric()
                ->minValue(0)
                ->helperText(__('Overrides the client rate for this project (optional)')),
            RichEditor::make('description')
                ->translateLabel()
                ->columnSpanFull()
                ->fileAttachmentsDisk('projects')
                ->fileAttachmentsDirectory(auth()->user()->company->id)
                ->fileAttachmentsVisibility('private'),
            SpatieTagsInput::make('tags'),
            Toggle::make('active')
                ->translateLabel()
                ->required()
                ->default(true),
        ];
    }
}
